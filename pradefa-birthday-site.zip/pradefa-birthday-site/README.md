# Website Ulang Tahun Pradefa

Proyek statis: `index.html` + folder `assets/` (foto, stiker, lagu). Tidak perlu build.

## Isi folder
- `index.html`  : halaman utama
- `assets/img/` : 86 foto
- `assets/stickers/` : stiker Pradefa dan stiker kucing
- `assets/audio/lagu.mp3` : lagu latar

> Struktur folder harus tetap sama. Jangan memindahkan atau mengganti nama file di `assets/`,
> karena `index.html` memanggilnya lewat alamat relatif (mis. `assets/img/p1.jpg`).

## Upload ke GitHub
1. Buat repository baru (pilih **Private** supaya foto tidak terlihat publik).
2. Klik **uploading an existing file**.
3. Seret ISI folder ini (file `index.html` dan folder `assets`), bukan folder induknya.
4. Batas upload lewat browser adalah 100 file per commit. Total proyek ini 98 file, jadi biasanya muat.
   Kalau gagal, upload dua kali:
   - Commit 1: `index.html`, `README.md`, `assets/audio`, `assets/stickers`
   - Commit 2: `assets/img`

## Deploy di Vercel
1. Masuk ke vercel.com dengan akun GitHub, lalu **Add New > Project**.
2. Pilih repository tadi dan klik **Import**.
3. **Framework Preset: Other**. Kosongkan Build Command dan Output Directory. Klik **Deploy**.
4. Selesai. Alamat `https://nama-proyek.vercel.app` bisa dikirim ke Defa.

## Mengubah isi
Ganti file di GitHub (atau tambah foto baru), lalu commit. Vercel otomatis deploy ulang.

## Catatan penting
- Buka lewat link Vercel, jangan klik dua kali `index.html` dari komputer. Kalau dibuka seperti itu,
  foto tetap tampil, tetapi lagu tidak bisa dimuat oleh browser. Untuk mencoba di komputer, pakai
  ekstensi **Live Server** di VS Code.
- Link Vercel bisa dibuka siapa pun yang punya alamatnya. Jangan dibagikan sebelum hari H.
- Font memakai Google Fonts, jadi butuh internet saat dibuka.
